This is where plain text files (readable on pretty much every platform) are at.
Normal files are in YAML but this has normal copies for anyone who needs them. :-)
