This is where files in JSON (JavaScript Object Notation) are now stored. 

Back in July 2020, files in the haiku-computer-list repo were converted to both YAML and JSON
so it'd be easier for any Haiku developers to parse and use. However, with the site update in March 2021,
the JSON format has been deprecated in order to make it easier to manage the hardware list.
